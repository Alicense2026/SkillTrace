# License Compliance Guide

This guide helps you comply with the Custom Source-Available License.

## Quick Compliance Checklist

- [ ] Include LICENSE-NOTICE file in your project
- [ ] Submit ALL modifications back to the original repository
- [ ] Do NOT offer as SaaS, managed service, or hosted service
- [ ] Include attribution in your documentation/UI
- [ ] Review license terms regularly for updates

## Allowed Uses ✅

1. **Internal Use**: Use within your organization for any purpose
2. **Embedding**: Include as component in your products (must contribute modifications)
3. **Consulting**: Offer consulting, support, implementation services
4. **Educational**: Free use by educational institutions (must contribute modifications)
5. **Distribution**: Share with others (under same license terms)

## Prohibited Uses ❌

1. **SaaS**: Cannot offer as Software-as-a-Service
2. **Managed Service**: Cannot offer as managed service
3. **Hosted Service**: Cannot host for others to use
4. **License Removal**: Cannot remove attribution or license notices

## Contribution Requirements

### What Must Be Contributed
- ALL modifications, enhancements, improvements
- New features you develop
- Bug fixes
- Documentation improvements
- Test improvements

### How to Contribute
1. Fork the repository
2. Make your changes
3. Submit pull request with:
   - Clear description of changes
   - Any relevant documentation
   - Tests for new features
4. Agree to contribute under same license

### No Time Limit
You must contribute modifications as you create them. There is no grace period.

## Attribution Requirements

### In Your Code
Include the LICENSE-NOTICE file in your project root.

### In Your UI/Documentation
Display:
```
Powered by [Software Name]
Licensed under Custom Source-Available License
Original repository: [Repository URL]
```

### For Distributions
Include full LICENSE file and all copyright notices.

## Violation Remedies

If you violate the license:

1. **First Violation**:
   - You have 30 days to fix after notice
   - Fix the violation and you're reinstated automatically

2. **Repeat Violations**:
   - Must fix violation
   - Create GitHub issue acknowledging violation
   - Request reinstatement
   - Wait for explicit permission

## Commercial Licensing

If these terms don't work for your use case, commercial licenses are available.
Contact: [YOUR CONTACT EMAIL]

## Questions?

- License questions: [YOUR CONTACT EMAIL]
- Technical questions: [GitHub Issues]
- Commercial licensing: [YOUR CONTACT EMAIL] 