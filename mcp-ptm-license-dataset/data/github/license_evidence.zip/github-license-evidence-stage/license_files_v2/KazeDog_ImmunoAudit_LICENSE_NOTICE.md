# License and distribution notice

No new open-source license is assigned by this packaging step. The author or
rights holder must choose and approve a code license before public distribution.
Preparing this local reviewer archive does not establish a public repository or
alter any existing ownership, institutional, data-use or confidentiality terms.

Third-party packages, pretrained weights and datasets retain their own licenses
and access conditions. The cBioPortal-derived example data in
examples/example_data/ are bundled under ODbL-1.0; their attribution and licence URI
are provided in examples/example_data/DATA_LICENSE.md. This dataset-specific licence
does not change the repository's software licence status. Other research data,
commercial fonts, model checkpoints and request archives are not bundled.
